import io
import json
import os
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

_TMP = tempfile.TemporaryDirectory(prefix="scamshield-gemini-test-")
os.environ["DATA_DIR"] = _TMP.name
os.environ["DB_PATH"] = str(Path(_TMP.name) / "test.db")
os.environ["SECRET_KEY"] = "gemini-retry-test-key-with-more-than-thirty-two-characters"
os.environ["ADMIN_KEY"] = ""
os.environ["NEWS_ENABLED"] = "false"

import server


class GeminiRetryTests(unittest.TestCase):
    def setUp(self):
        server.GEMINI_API_KEY = "test-key-not-real"
        server.GEMINI_MODEL = "gemini-primary-test"
        server.GEMINI_FALLBACK_MODELS = ["gemini-backup-test"]
        server.GEMINI_RETRIES = 1
        server.GEMINI_TOTAL_TIMEOUT = 25
        server.GEMINI_ATTEMPT_TIMEOUT = 8

    @staticmethod
    def success_response(text="Xin chào!"):
        payload = {"candidates": [{"content": {"parts": [{"text": text}]}}]}
        return io.BytesIO(json.dumps(payload).encode("utf-8"))

    @staticmethod
    def unavailable_error():
        return urllib.error.HTTPError(
            "https://example.invalid", 503, "Unavailable", {},
            io.BytesIO(b'{"error":{"code":503,"status":"UNAVAILABLE"}}')
        )

    def test_503_retries_then_uses_fallback_model(self):
        with patch("server.urllib.request.urlopen", side_effect=[
            self.unavailable_error(), self.unavailable_error(), self.success_response()
        ]) as urlopen, patch("server.time.sleep"):
            answer = server.gemini("system", "hello")
        self.assertEqual(answer, "Xin chào!")
        self.assertEqual(urlopen.call_count, 3)
        self.assertIn("gemini-backup-test", urlopen.call_args_list[-1].args[0].full_url)

    def test_timeout_moves_directly_to_fallback(self):
        with patch("server.urllib.request.urlopen", side_effect=[
            TimeoutError("timed out"), self.success_response("Fallback OK")
        ]) as urlopen:
            answer = server.gemini("system", "hello")
        self.assertEqual(answer, "Fallback OK")
        self.assertEqual(urlopen.call_count, 2)
        self.assertIn("gemini-backup-test", urlopen.call_args_list[-1].args[0].full_url)


if __name__ == "__main__":
    unittest.main()
