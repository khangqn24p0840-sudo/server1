# ScamShield server launcher for Windows PowerShell
# First run: create .env from .env.example and open it so you can fill your own keys.
# Keep real API keys only in .env (never commit or share that file).

Set-Location -Path $PSScriptRoot

$envFile = Join-Path $PSScriptRoot ".env"
$exampleFile = Join-Path $PSScriptRoot ".env.example"

if (-not (Test-Path $envFile)) {
    if (-not (Test-Path $exampleFile)) {
        Write-Host "Khong tim thay .env.example. Hay tai day du ma nguon server." -ForegroundColor Red
        exit 1
    }
    Copy-Item $exampleFile $envFile
    Write-Host ""
    Write-Host "Da tao file .env de ban dien API KEY va khoa quan tri." -ForegroundColor Green
    Write-Host "Notepad se mo file .env. Dien gia tri sau dau =, luu file, roi chay lai chay.ps1." -ForegroundColor Cyan
    Start-Process notepad.exe -ArgumentList $envFile -Wait
    Write-Host "Hay kiem tra va luu .env, sau do chay lai .\chay.ps1." -ForegroundColor Yellow
    exit 0
}

# Load local .env values into this PowerShell process.
foreach ($line in Get-Content $envFile) {
    $trimmed = $line.Trim()
    if (-not $trimmed -or $trimmed.StartsWith("#")) { continue }
    $separator = $trimmed.IndexOf("=")
    if ($separator -lt 1) { continue }
    $key = $trimmed.Substring(0, $separator).Trim()
    $value = $trimmed.Substring($separator + 1).Trim()
    if (($value.StartsWith('"') -and $value.EndsWith('"')) -or
        ($value.StartsWith("'") -and $value.EndsWith("'"))) {
        $value = $value.Substring(1, $value.Length - 2)
    }
    [Environment]::SetEnvironmentVariable($key, $value, "Process")
}

if (-not $env:ADMIN_KEY -or $env:ADMIN_KEY -eq "doi-thanh-chuoi-bi-mat-dai") {
    Write-Host "Canh bao: Hay thay ADMIN_KEY bang mot chuoi rieng, dai va kho doan trong .env." -ForegroundColor Yellow
}
if (-not $env:ANTHROPIC_API_KEY) {
    Write-Host "Chua co ANTHROPIC_API_KEY: chatbot AI day du chua hoat dong; server van chay che do co ban." -ForegroundColor Yellow
} else {
    Write-Host "Da doc ANTHROPIC_API_KEY tu .env (gia tri duoc an)." -ForegroundColor Green
}

$busy = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
if ($busy) {
    $pids = ($busy | Select-Object -ExpandProperty OwningProcess -Unique) -join ", "
    Write-Host "Cong 8000 dang duoc dung boi PID: $pids" -ForegroundColor Yellow
    Write-Host "Tat no truoc: taskkill /F /PID <so PID> roi chay lai file nay." -ForegroundColor Yellow
    exit 1
}

if (-not (Get-Command waitress-serve -ErrorAction SilentlyContinue)) {
    Write-Host "Thieu Waitress. Hay chay: pip install -r requirements.txt" -ForegroundColor Red
    exit 1
}

waitress-serve --threads=16 --port=8000 server:app
